import SwiftUI
import MapKit

struct ViewA: View {
    var body: some View {
        MapViewRepresentable(initialLocation: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060), regionRadius: 10000)
            .edgesIgnoringSafeArea(.all)
    }
}

struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}

