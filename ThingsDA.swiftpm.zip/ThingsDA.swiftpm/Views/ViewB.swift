import SwiftUI

struct ViewB: View {
    @State private var word: String = ""
    @State private var meaning: String = ""
    @State private var customMeanings: [String: String] = [
        "LOL": "Laughing out loud",
        "YOLO": "You only live once"
    ]
    
    var body: some View {
        VStack {
            TextField("Enter a word", text: $word)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Enter the meaning", text: $meaning)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: {
                // Add the word and meaning to the dictionary
                if !word.isEmpty && !meaning.isEmpty {
                    customMeanings[word.uppercased()] = meaning
                    word = ""
                    meaning = ""
                }
            }) {
                Text("Add Meaning")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding(.bottom)
            
            TextField("Search for meaning", text: $word, onCommit: {
                // Look up the word in the dictionary
                if let foundMeaning = customMeanings[word.uppercased()] {
                    meaning = foundMeaning
                } else {
                    meaning = "Meaning not found"
                }
            })
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            
            Text("Meaning: \(meaning)")
                .padding()
        }
        .padding()
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}

